import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RegistrarCitasComponent } from './pages/registrar-citas/registrar-citas.component';
import { ListarCitasComponent } from './pages/listar-citas/listar-citas.component';
import { ActualizarCitasComponent } from './pages/actualizar-citas/actualizar-citas.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MaterialModule } from '../material/material.module';

@NgModule({
  declarations: [
    RegistrarCitasComponent,
    ListarCitasComponent,
    ActualizarCitasComponent
  ],
  imports: [
    CommonModule,
    MaterialModule,
    FormsModule,
    ReactiveFormsModule,
 
  ]
})
export class CitasModule { }
