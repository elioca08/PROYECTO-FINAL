import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { CitasService } from 'src/app/services/citas.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-registrar-citas',
  templateUrl: './registrar-citas.component.html',
  styleUrls: ['./registrar-citas.component.css']
})
export class RegistrarCitasComponent implements OnInit {
 

  miFormulario:FormGroup = this.fb.group({

    nombre:['',Validators.required],
    apellido:['',Validators.required],
    edad:['',Validators.required],
    telefono:['',Validators.required],
    motivo:['',Validators.required],
    descripcion:['',Validators.required],
    fecha:[new Date(),Validators.required],
    hora:[,[Validators.min(7),Validators.max(17)]],
  });
  serializedDate = new FormControl((new Date()).toISOString());
  constructor(private fb:FormBuilder,private citasService:CitasService) { }

  ngOnInit(): void {
  }

  validarDatos(campo:string){
    if (this.miFormulario.controls[campo].errors && this.miFormulario.controls[campo].touched){

      return true

    }

  }

  Enviar(){
    console.log(this.miFormulario.value);
    if (this.miFormulario.invalid){
      
      this.miFormulario.markAllAsTouched();
      return  Swal.fire({
        icon: 'error',
        title: 'Oops...',
        text: 'Faltan campos por llenar!',
      })
      

    }

    this.citasService.guardarCita(this.miFormulario.value).subscribe(resp=>{
      
      Swal.fire(
        'Buen trabajo!',
        'Las cita se a asignado con exito!',
        'success'
      )

    },(error=>{

      return  Swal.fire({
        icon: 'error',
        title: 'Oops...',
        text: 'Ya hay una cita asignada a esa hora!',
      })
      

    }))

  }

}
