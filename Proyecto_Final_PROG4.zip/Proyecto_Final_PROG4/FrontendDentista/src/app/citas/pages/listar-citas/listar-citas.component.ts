import { Component, OnInit } from '@angular/core';
import { CitasService } from 'src/app/services/citas.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-listar-citas',
  templateUrl: './listar-citas.component.html',
  styleUrls: ['./listar-citas.component.css']
})
export class ListarCitasComponent implements OnInit {
  citas:any[]=[];
  constructor(private citasService:CitasService) { }
  //._id.$oid
  ngOnInit(): void {


    this.listarCitas();



  }


  listarCitas(){

    this.citasService.listarCitas().subscribe((resp:any[] )=> {
    
      this.citas=resp;
      console.log(this.citas);

    })

  }


  borrarCitas(id:string){

    Swal.fire({
      title: 'Esta seguro que atendio esta cita?',
      text: "Esta accion no tiene vuelta atras!",
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Si, dat cita por termianda!'
    }).then((result) => {
      if (result.isConfirmed) {

        this.citasService.BorrarCitas(id).subscribe(resp=>{

          Swal.fire(
            'Buen trabajo!',
            'Cita terminada!',
            'success'
          )

          console.log(resp);
          this.listarCitas();
        })

      }
    })

   

  }



}
