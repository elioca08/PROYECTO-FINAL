import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-actualizar-citas',
  templateUrl: './actualizar-citas.component.html',
  styleUrls: ['./actualizar-citas.component.css']
})
export class ActualizarCitasComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
