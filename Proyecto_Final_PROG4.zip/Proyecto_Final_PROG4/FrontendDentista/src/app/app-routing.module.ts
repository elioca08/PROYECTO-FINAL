import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ActualizarCitasComponent } from './citas/pages/actualizar-citas/actualizar-citas.component';
import { ListarCitasComponent } from './citas/pages/listar-citas/listar-citas.component';
import { RegistrarCitasComponent } from './citas/pages/registrar-citas/registrar-citas.component';

const routes: Routes = [

  {path: 'registrarcita',component:RegistrarCitasComponent},
  {path: 'listarcita',component:ListarCitasComponent},
  {path: 'actualizarcita',component:ActualizarCitasComponent},
  {path: '**',redirectTo:'registrarcita'},

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
