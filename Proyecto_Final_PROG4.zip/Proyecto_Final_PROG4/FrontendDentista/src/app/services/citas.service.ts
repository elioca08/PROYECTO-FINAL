import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class CitasService {

  constructor(private http:HttpClient) { }


  guardarCita(cita:any){

    const url = environment.api+'/citas';

    return this.http.post(url,cita)


  }

  listarCitas(){

    const url = environment.api+'/citas';
    return this.http.get(url)

  }

  BorrarCitas(id:string){

    const url = environment.api+'/citas/'+id;
    return this.http.delete(url);

  }


}
